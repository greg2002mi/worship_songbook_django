from django.contrib import admin
from import_export.admin import ImportExportModelAdmin
from .models import BlogPost, Comment, Category
# Register your models here.

class CategoryAdmin(admin.ModelAdmin):
    list_display = ('title', 'blog')
    

class BlogPostAdmin(ImportExportModelAdmin):
    list_display = ('title', 'author', 'short', 'content', 'image', 'dateTime')
    list_filter = ("dateTime",)
    search_fields = ['title', 'author', 'content']
    # raw_id_fields = ('user',)
    # date_hierarchy = 'created_on'
    # ordering = ('status', 'created_on')
    
class CommentAdmin(ImportExportModelAdmin):
    list_display = ('user', 'content','dateTime')
    list_filter = ("dateTime",)
    search_fields = ['content']
    # raw_id_fields = ('user',)
    # date_hierarchy = 'created_on'
    # ordering = ('status', 'created_on')    

admin.site.register(Category, CategoryAdmin)    
admin.site.register(BlogPost, BlogPostAdmin)
admin.site.register(Comment, CommentAdmin)