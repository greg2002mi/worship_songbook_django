from django.shortcuts import render, redirect, HttpResponse
from .models import BlogPost, Comment
from .forms import BlogPostForm, CommentForm
from django.contrib.auth.decorators import login_required
from django.views.generic import UpdateView
from django.views.generic.detail import DetailView

# Create your views here.
def blogs(request):
    posts = BlogPost.objects.all()
    posts = BlogPost.objects.filter().order_by('-dateTime')
    return render(request, "blog.html", {'posts':posts})

@login_required(login_url = '/login')
def add_blogs(request):
    if request.method=="POST":
        form = BlogPostForm(data=request.POST, files=request.FILES)
        if form.is_valid():
            blogpost = form.save(commit=False)
            blogpost.author = request.user
            blogpost.save()
            obj = form.instance
            alert = True
            return render(request, "add_blogs.html",{'obj':obj, 'alert':alert})
    else:
        form=BlogPostForm()
    return render(request, "add_blogs.html", {'form':form})

def blogs_comments(request, slug):
    blog = BlogPost.objects.filter(slug=slug).first()
    comments = Comment.objects.filter(blog=blog)
    if request.method=="POST":
        user = request.user
        content = request.POST.get('content','')
        # blog_id =request.POST.get('blog_id','')
        comment = Comment(user = user, content = content, blog=blog)
        comment.save()
    return render(request, "blog_comments.html", {'post':blog, 'comments':comments})

def Delete_Blog_Post(request, slug):
    posts = BlogPost.objects.get(slug=slug)
    if request.method == "POST":
        posts.delete()
        return redirect('/')
    return render(request, 'delete_blog_post.html', {'posts':posts})

class UpdatePostView(UpdateView):
    model = BlogPost
    template_name = 'edit_blog_post.html'
    fields = ['title', 'short', 'content', 'image']


class BlogDetail(DetailView):
    template_name= 'detail.html'
    model= BlogPost

    def get_context_data(self , **kwargs):
        data = super().get_context_data(**kwargs)
        connected_comments = Comment.objects.filter(CommentPost=self.get_object())
        number_of_comments = connected_comments.count()
        data['comments'] = connected_comments
        data['no_of_comments'] = number_of_comments
        data['comment_form'] = CommentForm()
        return data

    def post(self , request , *args , **kwargs):
        if self.request.method == 'POST':
            print('-------------------------------------------------------------------------------Reached here')
            comment_form = CommentForm(self.request.POST)
            if comment_form.is_valid():
                content = comment_form.cleaned_data['content']
                try:
                    parent = comment_form.cleaned_data['parent_comment']
                except:
                    parent=None

            

            new_comment = Comment(content=content , author = self.request.user , CommentPost=self.get_object() , parent_comment=parent)
            new_comment.save()
            return redirect(self.request.path_info)