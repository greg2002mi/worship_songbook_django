from .models import BlogPost, Comment
from django import forms
from django.utils.translation import gettext_lazy as _
from django_ckeditor_5.widgets import CKEditor5Widget

class BlogPostForm(forms.ModelForm):
    class Meta:
        model = BlogPost
        fields = ('title', 'short', 'content', 'image')
        widgets = {
            'title': forms.TextInput(attrs={'class':'form-control', 'placeholder':'Title of the Blog'}),
            'short': forms.Textarea(attrs={'class':'form-control', 'placeholder':'Write about 200 characters of introductory short...'}),
            "content": CKEditor5Widget(config_name='extends')
            #attrs={"class": "django_ckeditor_5"}, config_name="comment"
        }

class CommentForm(forms.ModelForm):
    class Meta:
        model = Comment
        

        fields = ['content','parent_comment']
        
        labels = {
            'content': _(''),
        }
        
        widgets = {
            'content' : forms.TextInput(),
        }